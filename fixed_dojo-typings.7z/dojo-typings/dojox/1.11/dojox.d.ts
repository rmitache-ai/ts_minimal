declare namespace dojox {
	/* Global DojoX Interface */
	interface DojoX {}
}
