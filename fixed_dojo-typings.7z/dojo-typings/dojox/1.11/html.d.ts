/// <reference path="html/metrics.d.ts" />
