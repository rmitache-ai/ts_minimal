/// <reference path="dojo/1.11/modules.d.ts" />
/// <reference path="dijit/1.11/modules.d.ts" />
/// <reference path="dojox/1.11/modules.d.ts" />
/// <reference path="doh/1.11/modules.d.ts" />
