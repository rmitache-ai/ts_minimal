/// <reference path="dojo.d.ts" />

declare var require: dojo.Require;
declare var define: dojo.Define;
