/// <reference path="index.d.ts" />

declare module 'doh/robot' {
	const robot: doh.Robot;
	export = robot;
}
